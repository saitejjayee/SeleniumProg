package com.SeleniumProg.*;

import java.util.*;

import org.openqa.selenium.*;
import org.testng.annotations.Test;

public class CountImage extends Test_Base {
	
	@Test
	public void getAllTextbox() {
		List<WebElement> textbox= driver.findElements(By.className("form-hint"));
		System.out.println("Textbox Count"+textbox.size());
		for(WebElement text:textbox) {
			System.out.println("Text Box Values are"+text.getText());
		}
	}
	@Test
	public void getAllLinks() {
		List<WebElement> links=driver.findElements(By.tagName("a"));
		System.out.println("Total Number of Links "+links.size());
		for(WebElement link:links) {
			System.out.println("Link Box Values are"+link.getAttribute("href"));
		}
	}
	
	@Test
	public void getAllImages() {
		List<WebElement> Images=driver.findElements(By.tagName("img"));
		System.out.println("Total Number of Images "+Images.size());
	}
	
}
