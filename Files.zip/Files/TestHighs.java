package com.SeleniumProg.*;

import org.openqa.selenium.*;
import org.testng.annotations.Test;

import com.SeleniumProg.pagesdemo.HRMPage;

public class TestHighs extends Test_Base {

	
	@Test
	public void initialTest() {
		
		HRMPage OR=new HRMPage(driver);
		R.getUsername().sendKeys("admin");
		R.getEnterpassword().sendKeys("admin1");
		R.getClickLogin().submit();
		
		R.getMarketPlace().click();
		R.getClickPIM().click();
		R.getTime().click();
		R.getMaintenance().click();
		driver.findElement(By.linkText("admin")).click();
		if(R.getWelcome().getText().contains("Welcome")){
			System.out.println("Welcome is found");
		}else {
			System.out.println("Welcome is not found");
		}
	}
}
