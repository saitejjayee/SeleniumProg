package com.SeleniumProg.*;

import java.io.*;
import javax.imageio.ImageIO;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.qa.pagedes.HRMPage;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class Emp_Test extends Test_Base {
	
	@Test
	public void EmployeeTestmatch() throws IOException, InterruptedException {
	HRMPage R = new HRMPage(driver);
	R.getUsername().sendKeys("admin");
	R.getEnterpassword().sendKeys("admin1");
	R.getClickLogin().submit();
	R.getClickPIM().click();

	
	if(R.getEmployeeSearch().getText().contains("Name")){
		Reporter.log("Employee Information is Present",true);
		Thread.sleep(1000);
		R.EnterEmployeeName().sendKeys("jayee sai");
		Reporter.log("Employee Information is Entered",true);
		String Screenshotname = "FullPagePassPIM";
        AShot SS = new AShot(); 
        Screenshot takeScreenshot = SS.shootingStrategy(ShootingStrategies.viewportPasting(200)).takeScreenshot(driver);
        
        String Destination = System.getProperty("user.dir")+"/Screenshots/"+ Screenshotname+".jpg";     
        
         
        ImageIO.write(takeScreenshot.getImage(), "jpg" , new File(Destination));
	}
	else {
		Reporter.log("Employee Information is not Present",true);
		String Screenshotname = "FullPageFailPIM";
        AShot SS = new AShot(); 
        Screenshot takeScreenshot = SS.shootingStrategy(ShootingStrategies.viewportPasting(200)).takeScreenshot(driver);
        
        String Destination = System.getProperty("user.dir")+"/Screenshots/"+ Screenshotname+".jpg";     
        
         
        ImageIO.write(takeScreenshot.getImage(), "jpg" , new File(Destination));
	}
	}
}
